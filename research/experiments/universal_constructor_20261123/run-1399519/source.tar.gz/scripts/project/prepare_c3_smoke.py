#!/usr/bin/env python3
"""Create a fresh one-update C3 HardBlock-Restart engineering smoke run."""

from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
from pathlib import Path

import pandas as pd

from verl.lean.mode_archive import ModeArchive


ROOT = Path(__file__).resolve().parents[2]
MODEL = "deepseek-ai/DeepSeek-Prover-V1.5-SFT"
MODEL_PATH = os.environ.get(
    "RESTRICTION_BASE_MODEL_PATH", "/scratch/memoozd/models/DeepSeek-Prover-V1.5-SFT"
)
MODEL_REVISION = "e9a6e6fbb67620d4e9c4944bc51ff7c435af12da"
ARCHIVE_SHA256 = "fcffb4a3dc9baf837d4780ec30855308ebc7f0c5086d607162889938b5e426d3"
TRAIN_ROWS = 16
VALID_ROWS = 16


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git_output(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path, help="new run directory; it must not exist")
    parser.add_argument(
        "--source", type=Path, default=ROOT / "data/mff-lwb-10k-seen.parquet"
    )
    parser.add_argument(
        "--archive", type=Path,
        default=ROOT / "runs/c0-base-20260804-seed42-complete/mode_archive.json",
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--verifier-root", type=Path)
    parser.add_argument(
        "--intervention",
        choices=("zero_advantage", "reject_reward"),
        default="zero_advantage",
    )
    parser.add_argument(
        "--selection",
        choices=("first", "high-signal"),
        default="first",
        help="high-signal is an engineering-only slice with blocked and alternative C0 modes",
    )
    args = parser.parse_args()

    run_dir = args.run_dir.resolve()
    if run_dir.exists():
        parser.error(f"refusing to reuse existing run directory: {run_dir}")
    if not args.source.is_file():
        parser.error(f"source parquet does not exist: {args.source}")
    if not args.archive.is_file() or sha256(args.archive) != ARCHIVE_SHA256:
        parser.error("archive is not the frozen registered C0 dominance archive")

    frame = pd.read_parquet(args.source)
    if "split" not in frame.columns or "theorem_full_name" not in frame.columns:
        parser.error("registered source lacks split or theorem identity")
    registered_train = frame.loc[frame["split"] == "train"]
    registered_valid = frame.loc[frame["split"] == "valid"]
    if len(registered_train) != 9655 or len(registered_valid) != 223:
        parser.error(
            "unexpected registered split sizes: "
            f"train={len(registered_train)}, valid={len(registered_valid)}"
        )

    archive = ModeArchive.load(args.archive)
    if args.selection == "first":
        train = registered_train.iloc[:TRAIN_ROWS].copy()
        selection = "first 16 rows of the registered training split in source order"
    else:
        scored: list[tuple[tuple[int, int, int], str]] = []
        for theorem in registered_train["theorem_full_name"]:
            theorem_name = str(theorem)
            dominant = archive.dominant_mode(theorem_name, threshold=0.5, min_verified=4)
            if dominant is None:
                continue
            counts = archive.counts[theorem_name]
            blocked_count = counts[dominant]
            alternative_count = counts.total() - blocked_count
            if alternative_count <= 0:
                continue
            scored.append(((min(blocked_count, alternative_count), blocked_count, counts.total()), theorem_name))
        selected_names = [name for _, name in sorted(scored, reverse=True)[:TRAIN_ROWS]]
        indexed = registered_train.set_index("theorem_full_name", drop=False)
        train = indexed.loc[selected_names].copy()
        selection = (
            "16 engineering-only training theorems maximizing observed C0 support for both "
            "the dominant mode and correct alternatives"
        )
    valid = registered_valid.iloc[:VALID_ROWS].copy()
    eligible = sum(
        archive.dominant_mode(str(theorem), threshold=0.5, min_verified=4) is not None
        for theorem in train["theorem_full_name"]
    )

    run_dir.mkdir(parents=True)
    train_path = run_dir / "train.parquet"
    valid_path = run_dir / "valid.parquet"
    archive_path = run_dir / "block_archive.json"
    train.to_parquet(train_path, index=False)
    valid.to_parquet(valid_path, index=False)
    shutil.copyfile(args.archive, archive_path)

    status = git_output("status", "--short") or "clean"
    condition = "C3 HardBlock-Restart" if args.intervention == "zero_advantage" else "C5 RewardReject-Restart"
    classification = (
        "engineering smoke, not a scientific C3 result"
        if args.intervention == "zero_advantage"
        else "engineering smoke, not a scientific C5 result"
    )
    lines = [
        f"# {condition} Smoke Metadata",
        "",
        "Status: prepared; no result exists yet.",
        "",
        f"- Git commit: `{git_output('rev-parse', 'HEAD')}`",
        f"- Dirty status: `{status}`",
        f"- Pristine actor and frozen reference: `{MODEL}`",
        f"- Runtime model path: `{MODEL_PATH}`",
        f"- Model revision: `{MODEL_REVISION}`",
        f"- Source data: `{args.source}` (`{sha256(args.source)}`)",
        f"- Derived training smoke data: {len(train)} rows (`{sha256(train_path)}`)",
        f"- Derived validation smoke data: {len(valid)} rows (`{sha256(valid_path)}`)",
        f"- Training selection: {selection}",
        "- Validation selection: first 16 registered-valid rows in source order",
        f"- Seed: {args.seed}",
        "- Proposal budget: 32 per theorem; 512 total training proposals",
        "- Expected optimizer updates: 1 if at least 256 samples retain training signal",
        "- PPO epochs: 2",
        "- KL loss coefficient: 0.10",
        "- Rank penalty: 0.0",
        "- Hard blocking: enabled; threshold >0.50; minimum verified correct 4",
        f"- Hard-block intervention: `{args.intervention}`",
        f"- C0-dominant theorems in smoke slice: {eligible}/16",
        f"- Run-local block archive: `{archive_path}` (`{sha256(archive_path)}`)",
        "- Resume: disabled; optimizer and rollout buffer start fresh",
        f"- Classification: {classification}",
    ]
    if args.verifier_root:
        lines.append(f"- DeepSeek verifier workspace: `{args.verifier_root.resolve()}`")
    lines.extend([
        "",
        "Append resolved config, environment, hardware, wall-clock, proposal,",
        "verified, correct, blocked, and trained counts after completion.",
    ])
    (run_dir / "RUN_METADATA.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(run_dir)


if __name__ == "__main__":
    main()
